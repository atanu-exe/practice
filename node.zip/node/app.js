const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
const path = require('path');
const port = 3000;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// Define a route to render the HTML file
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Default username for MySQL in WAMP
    password: '', // Default password for MySQL in WAMP
    database: 'demo_data' // Replace 'your_database_name' with your database name
});
connection.connect(err => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

app.get('/employees', (req, res) => {
    connection.query('SELECT COUNT(*) as total FROM employees', (err, countResult) => {
        if (err) {
            console.error('Error retrieving total user count:', err);
            res.status(500).send('Internal Server Error');
            return;
        }

        const totalUsers = countResult[0].total;




        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;
        const sql = `SELECT * FROM employees LIMIT ?, ?`;
        connection.query(sql, [offset, limit], (err, results) => {
            if (err) {
                console.error('Error retrieving users:', err);
                res.status(500).send('Internal Server Error');
                return;
            }
            res.render('employees', { users: results, page: page, totalUsers: totalUsers }); // Pass data to the view
        });
    });
});
app.get('/employees/edit', (req, res) => {
    connection.query('SELECT COUNT(*) as total FROM employees', (err, countResult) => {
        if (err) {
            console.error('Error retrieving total user count:', err);
            res.status(500).send('Internal Server Error');
            return;
        }





        const userId = parseInt(req.query.employeeNumber);
        const sql = `SELECT * FROM employees WHERE employeeNumber = ?`;
        connection.query(sql, [userId], (err, results) => {
            if (err) {
                console.error('Error retrieving user:', err);
                res.status(500).send('Internal Server Error');
                return;
            }
            res.render('employees-edit', { user: results[0] }); // Pass data to the view
        });

    });
});
app.post('/employees/save', (req, res) => {
    const { employeeNumber, f_name, l_name } = req.body;
    connection.query('UPDATE employees SET firstName = ?, lastName = ? WHERE employeeNumber = ?', [f_name, l_name, employeeNumber], (err, result) => {
        if (err) {
            console.error('Error updating employee data:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        console.log('Employee data updated successfully');
        res.sendStatus(200); // Send success response
    });
});


app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});