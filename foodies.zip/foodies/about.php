<?php
include __DIR__ . "/vendor/autoload.php";
require 'Product.php';
$product = new Product();
$products = $product->getproduct();

require_once 'includes/header.php'; ?>



<!-- Navbar & Hero Start -->
<div class="container-xxl position-relative p-0">
    <?php require_once 'includes/nav-bar.php' ?>

    <div class="container-xxl py-5 bg-dark hero-header mb-5">
        <div class="container text-center my-5 pt-5 pb-4">
            <h1 class="display-3 text-white mb-3 animated slideInDown">About Us</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb justify-content-center text-uppercase">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page">About</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<!-- Navbar & Hero End -->


<?php require_once 'includes/about.php';
require_once 'includes/team.php';
require_once 'includes/footer.php';
?>