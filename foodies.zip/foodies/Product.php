<?php

require 'includes/db_connection.php';

class Product
{
    private $conn;

    function __construct()
    {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    function getproduct()
    {
        if ($this->conn) {
            $products = array();
            $query = "SELECT productCode,productDescription,MSRP,quantityInStock, productName FROM products LIMIT 10";
            $statement = $this->conn->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            if ($result) {
                // Iterate through the result set and store each product in the $products array
                $products = array();
                foreach ($result as $row) {
                    $product = new stdClass();

                    $product->id=$row['productCode'];
                    $product->name=$row['productName'];
                    $product->price=$row['MSRP'];
                    $product->desc=$row['productDescription'];
                    $product->quantity=$row['quantityInStock'];
                    $products[]=$product;
                }
                return $products;
            } else {
                return false;
            }
        }
    }
}
